"""Offline integrity, Python syntax and small diagnostic checks; no simulation."""
import ast
import csv
import json
import sys
sys.dont_write_bytecode = True
import hashlib
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for line in (ROOT / 'SHA256SUMS.txt').read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
sources = list(ROOT.rglob('*.py'))
for file in sources:
    ast.parse(file.read_text(), filename=str(file.relative_to(ROOT)))
spec = importlib.util.spec_from_file_location('diagnostics', ROOT / 'P3/code/rollout_diagnostics.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
for high, final, expected in [(0.45, 0.425, 'cube not lifted'), (0.52, 0.44, 'cube dropped after lift'), (0.52, 0.50, 'target not reached')]:
    assert module.classify_rollout_failure(high, final) == expected
print(f'Integrity OK; {len(sources)} Python files parse; 3 diagnostic checks pass.')

with (ROOT / 'P3/evidence/all_150_rollouts.csv').open() as handle:
    rows = list(csv.DictReader(handle))
assert len(rows) == 150
for name, count in [('own_bc1k', 30), ('provided_bc10k', 46), ('rl_expert', 49)]:
    subset = [r for r in rows if r['policy'] == name]
    assert len(subset) == 50 and sum(r['success'] == 'True' for r in subset) == count
for file in (ROOT / 'P2/evidence').glob('*/episodes.csv'):
    with file.open() as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == 10 and [int(r['reset_seed']) for r in rows] == list(range(42, 52))
print('P3: 150 rows and all three success totals verified; P2: five paired 10-episode evaluations verified.')
