"""Standard-library tests only: no training, JAX/Torch imports, GPU or real rendering.

Run: python -m unittest discover -s tests -p 'test_evaluate_p2.py' -v
Mocks validate orchestration and contracts, not physics, codecs, or GPU compatibility.
"""
import ast
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

SCRIPT = Path(__file__).resolve().parents[1] / "evaluate_p2.py"
spec = importlib.util.spec_from_file_location("p2_evaluator_under_test", SCRIPT)
evaluator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evaluator)


class EvaluatorStaticTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.run_dir = self.repo / "logs" / "scale_500"
        self.run_dir.mkdir(parents=True)
        self.checkpoint_path = self.run_dir / "model_499.pt"
        self.checkpoint_path.write_bytes(b"mock checkpoint, not executable")
        self.exit_path = self.root / "training.exit"
        self.exit_path.write_text("0\n")
        self.args = SimpleNamespace(repo=self.repo, checkpoint=self.checkpoint_path,
                                    experiment="scale_500", run_name="scale_500",
                                    expected_iter=499, out=self.root / "out",
                                    training_exit_file=self.exit_path,
                                    training_record=None, device="cuda:0")
        self.checkpoint = {**evaluator.file_metadata(self.checkpoint_path), "saved_iteration": 499}

    def cli(self):
        return ["--repo", str(self.repo), "--checkpoint", str(self.checkpoint_path),
                "--experiment", "scale_500", "--run-name", "scale_500", "--expected-iter", "499",
                "--out", str(self.args.out), "--training-exit-file", str(self.exit_path)]

    def make_record(self):
        config_path = self.root / "effective_config.json"
        config_path.write_text(json.dumps({"environment_effective": {
            "reward_config": {"scales": {**evaluator.DEFAULT_REWARD_SCALES, "box_target": 16.0}}}}))
        log_path = self.root / "training.log"
        log_path.write_text("mock training log\n")
        record = {
            "schema_version": 1, "experiment": "scale_500", "run_name": "scale_500",
            "state": "completed", "exit_code": 0, "command": ["python", "train_scale_500.py"],
            "repo": str(self.repo), "run_dir": str(self.run_dir), "checkpoint": self.checkpoint,
            "expected_iterations": 500, "expected_final_iteration": 499,
            "started_utc": "2026-10-04T00:00:00+00:00", "finished_utc": "2026-10-04T00:10:00+00:00",
            "process_wall_seconds": 600.0, "training_learn_seconds": 580.0,
            "training_log": str(log_path), "training_exit_file": str(self.exit_path),
            "training_reward": {"tag": "Train/mean_reward", "last": {"step": 499, "value": 100.0, "wall_time": 0}},
            "effective_config": str(config_path), "effective_config_sha256": evaluator.sha256(config_path),
            "source_commit": evaluator.OFFICIAL_COMMIT, "source_sha256": evaluator.SOURCE_SHA256,
            "source_variant_sha256": "example_recorded_only_digest", "baseline_provenance": "P1 reuse",
        }
        self.args.training_record = self.root / "training_record.json"
        self.write_record(record)
        return record

    def write_record(self, record):
        self.args.training_record.write_text(json.dumps(record))

    def test_module_top_level_imports_are_stdlib_only(self):
        tree = ast.parse(SCRIPT.read_text())
        roots = []
        for node in tree.body:
            if isinstance(node, ast.Import):
                roots.extend(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                roots.append(node.module.split(".")[0])
        self.assertTrue(set(roots) <= sys.stdlib_module_names, roots)

    def test_cli_has_explicit_checkpoint_expected_iter_run_name(self):
        args = evaluator.parse_args(self.cli())
        self.assertEqual(args.checkpoint, self.checkpoint_path)
        self.assertEqual(args.expected_iter, 499)
        self.assertEqual(args.run_name, "scale_500")
        self.assertFalse(self.args.out.exists())

    def test_missing_expected_iter_fails(self):
        argv = self.cli()
        start = argv.index("--expected-iter")
        del argv[start:start + 2]
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            evaluator.parse_args(argv)

    def test_paired_seeds_cannot_be_overridden(self):
        self.assertEqual(evaluator.SEEDS, tuple(range(42, 52)))
        for extra in (["--seed", "7"], ["--episodes", "2"], ["--video-episodes", "0"]):
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                evaluator.parse_args(self.cli() + extra)

    def test_real_official_file_fingerprints_if_checkout_present(self):
        official_repo = SCRIPT.parents[2] / "cpu_practice" / "ap-physicalai-1-main"
        if not official_repo.exists():
            self.skipTest("Pinned course checkout unavailable on this host")
        self.assertEqual(evaluator.verify_sources(official_repo), evaluator.SOURCE_SHA256)

    def test_source_tamper_fails(self):
        for name in evaluator.SOURCE_SHA256:
            (self.repo / name).write_text("not the official source\n")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            evaluator.verify_sources(self.repo)

    def test_without_record_does_not_claim_training_verified(self):
        evidence = evaluator.training_evidence(self.args, self.checkpoint)
        self.assertFalse(evidence["training_record_consistency_verified"])
        self.assertEqual(evidence["training_record_status"], "NOT_SUPPLIED_TRAINING_UNVERIFIED")
        self.assertIsNone(evidence["training_reward"]["last"])

    def test_exit_must_be_zero(self):
        for bad in ("1", "", "running", "00"):
            self.exit_path.write_text(bad)
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                evaluator.training_evidence(self.args, self.checkpoint)

    def test_actual_run_name_must_match(self):
        self.args.run_name = "wrong_run"
        with self.assertRaisesRegex(ValueError, "actual parent"):
            evaluator.training_evidence(self.args, self.checkpoint)

    def test_record_bound_to_checkpoint_and_training_config(self):
        self.make_record()
        evidence = evaluator.training_evidence(self.args, self.checkpoint)
        self.assertTrue(evidence["training_record_consistency_verified"])
        self.assertEqual(evidence["training_reward"]["reward_scales"]["box_target"], 16.0)
        self.assertNotEqual(evidence["training_reward"]["label"], evaluator.EVALUATION_REWARD_LABEL)

    def test_record_identity_exit_iteration_and_source_tampering_fail(self):
        original = self.make_record()
        for key, value in (("experiment", "other"), ("run_name", "other"), ("state", "running"),
                           ("exit_code", 1), ("expected_final_iteration", 1000),
                           ("expected_iterations", 1001), ("source_commit", "other"),
                           ("source_sha256", {}), ("repo", "/other"), ("training_exit_file", "/other"),
                           ("run_dir", "/other"), ("effective_config_sha256", "bad")):
            record = copy.deepcopy(original)
            record[key] = value
            self.write_record(record)
            with self.subTest(key=key), self.assertRaises(ValueError):
                evaluator.training_evidence(self.args, self.checkpoint)

    def test_record_checkpoint_tampering_fails(self):
        original = self.make_record()
        for key, value in (("path", "/other"), ("bytes", 1), ("sha256", "bad"), ("saved_iteration", 500)):
            record = copy.deepcopy(original)
            record["checkpoint"][key] = value
            self.write_record(record)
            with self.subTest(key=key), self.assertRaises(ValueError):
                evaluator.training_evidence(self.args, self.checkpoint)

    def fake_torch(self, iteration=499, finite=True):
        weights = {"layer.weight": object()}
        return SimpleNamespace(load=Mock(return_value={"iter": iteration, "actor_state_dict": weights,
                                                      "critic_state_dict": weights}),
                               is_tensor=lambda value: True,
                               isfinite=lambda value: SimpleNamespace(all=lambda: finite),
                               manual_seed=Mock())

    def test_saved_iteration_checked_not_filename(self):
        torch = self.fake_torch(iteration=500)
        with self.assertRaisesRegex(ValueError, "saved iteration"):
            evaluator.verify_checkpoint(self.checkpoint_path, 499, torch)

    def test_finite_actor_and_critic_required(self):
        with self.assertRaisesRegex(ValueError, "Nonfinite"):
            evaluator.verify_checkpoint(self.checkpoint_path, 499, self.fake_torch(finite=False))
        result = evaluator.verify_checkpoint(self.checkpoint_path, 499, self.fake_torch())
        self.assertEqual(result["finite_weight_tensor_counts"], {"actor_state_dict": 1, "critic_state_dict": 1})

    def rows(self):
        return [{"reset_seed": seed, "success": seed % 2 == 0, "grasped": True,
                 "common_default_evaluation_reward": float(seed), "final_distance_m": 0.1,
                 "terminated_early": False} for seed in evaluator.SEEDS]

    def test_summary_uses_success_primary_and_grasp_secondary(self):
        summary = evaluator.summarize(self.rows())
        self.assertEqual(summary["primary_metric"], "success_rate")
        self.assertEqual(summary["secondary_metric"], "grasp_rate")
        self.assertEqual(summary["success_rate"], 0.5)
        self.assertEqual(summary["grasp_rate"], 1.0)
        self.assertEqual(summary["mean_common_default_evaluation_reward"], 46.5)
        self.assertNotIn("mean_reward", summary)

    def test_incomplete_unpaired_duplicate_and_reordered_seeds_fail(self):
        rows = self.rows()
        for bad in (rows[:-1], rows[::-1], [rows[0]] * 10):
            with self.assertRaisesRegex(ValueError, "seeds 42--51"):
                evaluator.summarize(bad)

    def test_wilson_intervals(self):
        low, high = evaluator.wilson(0, 10)
        self.assertAlmostEqual(low, 0.0)
        self.assertGreater(high, 0.27)
        self.assertLess(high, 0.28)
        low, high = evaluator.wilson(10, 10)
        self.assertAlmostEqual(high, 1.0)
        self.assertGreater(low, 0.72)

    def video_modules(self, corrupt=False):
        frames = []
        frame = SimpleNamespace(shape=(480, 640, 3))
        class Writer:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def append_data(self, value):
                frames.append(value)
        class Reader:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def __iter__(self):
                for index, value in enumerate(frames):
                    if corrupt and index == 3:
                        raise RuntimeError("mock corruption after three frames")
                    yield value
        def writer(path, **kwargs):
            Path(path).write_bytes(b"mock encoded file")
            self.assertEqual(kwargs["fps"], 25.0)
            return Writer()
        iio = SimpleNamespace(get_writer=writer, get_reader=lambda path: Reader())
        modules = {"imageio": SimpleNamespace(v2=iio), "imageio.v2": iio,
                   "numpy": SimpleNamespace(asarray=lambda value: value)}
        env = SimpleNamespace(dt=0.02, render=Mock(side_effect=lambda states, **kwargs: [frame] * len(states)))
        return modules, env, frames

    def test_video_streams_default_camera_every_two_steps_bounded_batches(self):
        modules, env, frames = self.video_modules()
        with patch.dict(sys.modules, modules):
            result = evaluator.save_video(env, list(range(151)), self.root / "video.mp4")
        self.assertEqual(result["frames"], 76)
        self.assertEqual(result["decoded_frames"], 76)
        self.assertTrue(result["verified_decodable"])
        self.assertEqual(result["manual_visual_review"], "NOT_PERFORMED")
        selected = []
        for call in env.render.call_args_list:
            states = call.args[0]
            self.assertLessEqual(len(states), 10)
            self.assertEqual(call.kwargs, {"height": 480, "width": 640})
            selected.extend(states)
        self.assertEqual(selected, list(range(0, 151, 2)))
        self.assertEqual(len(frames), 76)

    def test_all_frames_are_decoded_not_only_first_frame(self):
        modules, env, _ = self.video_modules(corrupt=True)
        with patch.dict(sys.modules, modules), self.assertRaisesRegex(RuntimeError, "corruption"):
            evaluator.save_video(env, list(range(151)), self.root / "video.mp4")

    def fake_rollout_objects(self):
        def array(values):
            return SimpleNamespace(tolist=lambda: values)
        initial, final = SimpleNamespace(z=0.03), SimpleNamespace(z=0.2)
        def rollout(env, policy, rng, episode_length, is_dict_obs, **kwargs):
            # Exactly at thresholds: both success and grasp must remain false.
            self.assertEqual(kwargs["cube_x"], None)
            self.assertEqual(kwargs["cube_y"], None)
            self.assertEqual(kwargs["obs_noise"], 0.0)
            return [initial, final], float(rng), False, False, 0.05
        official = SimpleNamespace(rollout_single_episode=Mock(side_effect=rollout),
                                   _cube_z=lambda state: state.z,
                                   _box_pos=lambda state: array([0.7, 0.0, state.z]),
                                   _target_pos=lambda state: array([0.7, 0.0, 0.25]))
        env = SimpleNamespace(reset=Mock(), step=Mock(), observation_size={"state": 10})
        jax = SimpleNamespace(jit=lambda fn: fn, random=SimpleNamespace(PRNGKey=lambda seed: seed))
        cfg = SimpleNamespace(episode_length=150)
        return env, cfg, official, jax, self.fake_torch()

    def test_orchestration_calls_unchanged_rollout_ten_times_and_three_videos(self):
        self.args.out.mkdir()
        env, cfg, official, jax, torch = self.fake_rollout_objects()
        with contextlib.redirect_stdout(io.StringIO()), patch.object(evaluator, "save_video") as save:
            save.return_value = {"status": "DECODE_VERIFIED", "verified_decodable": True}
            rows, errors = evaluator.evaluate_episodes(self.args, env, "policy", cfg, official, jax, torch)
        self.assertEqual(official.rollout_single_episode.call_count, 10)
        self.assertEqual(save.call_count, 3)
        self.assertEqual([call.args[0] for call in torch.manual_seed.call_args_list], list(range(42, 52)))
        self.assertEqual([row["reset_seed"] for row in rows], list(range(42, 52)))
        self.assertEqual([Path(call.args[2]).name for call in save.call_args_list],
                         ["episode_01_seed_42.mp4", "episode_02_seed_43.mp4", "episode_03_seed_44.mp4"])
        self.assertTrue(all(not row["success"] and not row["grasped"] for row in rows))
        self.assertEqual(len((self.args.out / "episodes.jsonl").read_text().splitlines()), 10)
        self.assertEqual(errors, [])

    def test_video_failure_preserves_metrics_and_is_explicit(self):
        self.args.out.mkdir()
        env, cfg, official, jax, torch = self.fake_rollout_objects()
        with contextlib.redirect_stdout(io.StringIO()), patch.object(evaluator, "save_video", side_effect=RuntimeError("codec")):
            rows, errors = evaluator.evaluate_episodes(self.args, env, "policy", cfg, official, jax, torch)
        self.assertEqual(len(rows), 10)
        self.assertEqual(len(errors), 3)
        self.assertFalse(rows[0]["video"]["verified_decodable"])

    def test_output_directory_guard_runs_before_dependency_imports(self):
        self.args.out.mkdir()
        (self.args.out / "existing.json").write_text("{}")
        with self.assertRaisesRegex(ValueError, "Output directory"):
            evaluator.main(self.cli())

    def test_json_rejects_nan_and_manifest_hashes_only_existing_files(self):
        with self.assertRaises(ValueError):
            evaluator.write_json(self.root / "bad.json", {"value": float("nan")})
        self.assertFalse((self.root / "bad.json").exists())
        evaluator.write_json(self.root / "good.json", {"value": 1})
        paths = {entry["path"] for entry in evaluator.artifact_manifest(self.root)}
        self.assertIn("good.json", paths)
        self.assertNotIn("artifact_manifest.json", paths)

    def test_no_results_created_by_import_or_cli(self):
        evaluator.parse_args(self.cli())
        self.assertFalse(self.args.out.exists())

    def main_mocks(self, changed_defaults=False):
        env, cfg, official, jax, torch = self.fake_rollout_objects()
        config = {"episode_length": 150, "reward_config": {"scales": dict(evaluator.DEFAULT_REWARD_SCALES)}}
        if changed_defaults:
            config["reward_config"]["scales"]["box_target"] = 16.0
        cfg.to_dict = lambda: copy.deepcopy(config)
        class FakeEnv:
            pass
        full_env = FakeEnv()
        full_env.__dict__.update(env.__dict__)
        full_env._config, full_env.dt = cfg, 0.02
        runner = SimpleNamespace(get_inference_policy=lambda device: "policy")
        official.__file__ = str(self.repo / "inference.py")
        official.ENV_NAME = "PandaPickCube"
        official.SUCCESS_THRESHOLD, official.GRASP_Z_THRESHOLD = 0.05, 0.2
        official.build_runner = lambda checkpoint, device: runner
        torch.__version__, torch.version = "mock", SimpleNamespace(cuda="mock")
        jax.devices = lambda: ["mock_device"]
        registry = SimpleNamespace(get_default_config=lambda name: cfg,
                                   load=lambda name, config: full_env)
        return {"torch": torch, "jax": jax, "inference": official,
                "mujoco_playground": SimpleNamespace(registry=registry),
                "device_utils": SimpleNamespace(apply_mjx_overrides_to_playground_cfg=lambda cfg: cfg)}

    def test_full_main_mock_writes_honest_results_and_manifest(self):
        with patch.dict(sys.modules, self.main_mocks()), patch.object(sys, "path", list(sys.path)), \
             patch.dict(evaluator.os.environ), patch.object(evaluator, "verify_sources", return_value=evaluator.SOURCE_SHA256), \
             patch.object(evaluator, "save_video", return_value={"status": "DECODE_VERIFIED", "verified_decodable": True}), \
             contextlib.redirect_stdout(io.StringIO()):
            code = evaluator.main(self.cli())
        self.assertEqual(code, 0)
        summary = json.loads((self.args.out / "summary.json").read_text())
        self.assertEqual(summary["status"], "METRICS_AND_VIDEO_FILES_COMPLETE")
        self.assertEqual(summary["episodes"], 10)
        self.assertEqual(summary["successes"], 0)
        self.assertEqual(summary["training_record_status"], "NOT_SUPPLIED_TRAINING_UNVERIFIED")
        self.assertIsNone(summary["training_reward"]["last"])
        self.assertEqual(summary["manual_visual_review"], "NOT_PERFORMED")
        metadata = json.loads((self.args.out / "metadata.json").read_text())
        self.assertEqual(metadata["evaluation_reward_scales"], evaluator.DEFAULT_REWARD_SCALES)
        manifest = json.loads((self.args.out / "artifact_manifest.json").read_text())
        self.assertIn("episodes.csv", {entry["path"] for entry in manifest})

    def test_changed_installed_defaults_fail_before_output_creation(self):
        with patch.dict(sys.modules, self.main_mocks(changed_defaults=True)), \
             patch.object(sys, "path", list(sys.path)), patch.dict(evaluator.os.environ), \
             patch.object(evaluator, "verify_sources", return_value=evaluator.SOURCE_SHA256), \
             self.assertRaisesRegex(ValueError, "default reward changed"):
            evaluator.main(self.cli())
        self.assertFalse(self.args.out.exists())


if __name__ == "__main__":
    unittest.main()
