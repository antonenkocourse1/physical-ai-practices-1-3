"""Bounded real MuJoCo scene updates for an alternative notebook manual interface.

Run only via the isolated Python 3.12 interpreter. No server, tunnel, training,
policy inference, or automatic slider animation. Every request exits.
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import sys
import uuid

# Physics is the native CPU MuJoCo implementation. JAX is needed only to load
# the identical Playground model, never for training or a GPU compilation.
os.environ["JAX_PLATFORMS"] = "cpu"
os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import mujoco
import numpy as np

STEPS = 200
STATE_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def official_model(repo):
    """Use the exact model construction and reset route in panda_teleop.py."""
    repo = Path(repo).resolve()
    required = [repo / name for name in ("panda_teleop.py", "config.py", "device_utils.py")]
    if not all(path.is_file() for path in required):
        raise RuntimeError(f"Official course source missing in {repo}")
    spec = importlib.util.find_spec("mujoco_playground")
    if spec is None or spec.origin is None:
        raise RuntimeError("Playground is not installed in isolated Python")
    package = Path(spec.origin).parent
    # Avoid triggering Playground's asset download helper.
    panda_assets = package / "external_deps/mujoco_menagerie/franka_emika_panda"
    if not (panda_assets / "mjx_panda.xml").is_file() or not (panda_assets / "assets").is_dir():
        raise RuntimeError("Existing Panda assets missing; refusing network/download setup")
    sys.path.insert(0, str(repo))
    import jax
    from config import ENV_NAME
    from device_utils import apply_mjx_overrides_to_playground_cfg
    from mujoco_playground import registry

    if ENV_NAME != "PandaPickCube":
        raise RuntimeError(f"Expected official PandaPickCube, found {ENV_NAME}")
    jax.config.update("jax_default_matmul_precision", "highest")
    config = registry.get_default_config(ENV_NAME)
    apply_mjx_overrides_to_playground_cfg(config)
    env = registry.load(ENV_NAME, config=config)
    model = env.mj_model
    if model.nu != 8:
        raise RuntimeError(f"Expected eight actuators, found {model.nu}")
    if any(str(device.platform) != "cpu" for device in jax.devices()):
        raise RuntimeError("Model-loader JAX backend is not CPU")
    data = mujoco.MjData(model)
    reset(model, data)
    rows = []
    for index in range(model.nu):
        if int(model.actuator_trntype[index]) != int(mujoco.mjtTrn.mjTRN_JOINT):
            raise RuntimeError("Unexpected actuator transmission; inspect model")
        joint_id = int(model.actuator_trnid[index, 0])
        joint_name = model.joint(joint_id).name
        expected = f"joint{index + 1}" if index < 7 else "finger_joint1"
        if joint_name != expected or float(model.actuator_gear[index, 0]) != 1.0:
            raise RuntimeError("Unexpected actuator mapping or gear; inspect model")
        rows.append({
            "index": index,
            "name": model.actuator(index).name,
            "joint": joint_name,
            "qpos_index": int(model.jnt_qposadr[joint_id]),
            "unit": "rad" if index < 7 else "m",
            "ctrlrange": model.actuator_ctrlrange[index].tolist(),
            "home_ctrl": float(data.ctrl[index]),
            "gear": model.actuator_gear[index].tolist(),
            "gainprm": model.actuator_gainprm[index].tolist(),
            "biasprm": model.actuator_biasprm[index].tolist(),
            "control_note": "joint position target" if index < 7 else
                "one finger displacement; second finger is equality-coupled; not total jaw gap",
        })
    joints = [{"name": model.joint(j).name, "qpos_index": int(model.jnt_qposadr[j])}
              for j in range(model.njnt)
              if model.joint(j).name in [f"joint{i}" for i in range(1, 8)] +
              ["finger_joint1", "finger_joint2"]]
    metadata = {
        "schema_version": 1,
        "interface": "alternative notebook manual interface; not original VNC or Docker",
        "env_name": ENV_NAME,
        "keyframe_index": 0 if model.nkey else None,
        "keyframe_name": model.key(0).name if model.nkey else None,
        "home_qpos": data.qpos.tolist(),
        "home_ctrl": data.ctrl.tolist(),
        "nu": model.nu, "nq": model.nq, "nv": model.nv,
        "timestep_seconds": float(model.opt.timestep),
        "physics_steps_per_apply": STEPS,
        "physics_backend": "native MuJoCo CPU mj_step",
        "model_loader_jax_devices": [str(device) for device in jax.devices()],
        "python": sys.version,
        "mujoco_version": mujoco.__version__,
        "playground_version": importlib.metadata.version("playground"),
        "source_files_sha256": {path.name: digest(path) for path in required},
        "actuators": rows,
        "robot_joints": joints,
        "equality_constraints": {
            "type": model.eq_type.tolist(), "obj1id": model.eq_obj1id.tolist(),
            "obj2id": model.eq_obj2id.tolist(), "data": model.eq_data.tolist(),
        },
        "render_backend": os.environ["MUJOCO_GL"],
        "render_note": "one actual scene PNG per request; EGL may use GPU only while jobs are idle",
    }
    return model, data, metadata


def reset(model, data):
    if model.nkey > 0:
        mujoco.mj_resetDataKeyframe(model, data, 0)
    else:
        mujoco.mj_resetData(model, data)
    mujoco.mj_forward(model, data)


def step(model, data, controls):
    controls = np.asarray(controls, dtype=np.float64)
    if controls.shape != (8,) or not np.isfinite(controls).all():
        raise ValueError("Exactly eight finite control values are required")
    limits = model.actuator_ctrlrange
    if np.any(controls < limits[:, 0]) or np.any(controls > limits[:, 1]):
        raise ValueError("Control value is outside the official actuator range")
    data.ctrl[:] = controls
    for _ in range(STEPS):
        mujoco.mj_step(model, data)
    if not np.isfinite(data.qpos).all() or not np.isfinite(data.qvel).all():
        raise RuntimeError("Non-finite physics state; refusing to save it")
    mujoco.mj_forward(model, data)


def render(model, data, destination):
    import imageio.v3 as iio
    with mujoco.Renderer(model, height=480, width=640) as renderer:
        renderer.update_scene(data)
        pixels = renderer.render()
        if pixels.shape != (480, 640, 3) or pixels.dtype != np.uint8:
            raise RuntimeError("Unexpected renderer image")
        iio.imwrite(destination, pixels)


def save_state(model, data, path):
    state = np.empty(mujoco.mj_stateSize(model, STATE_SPEC), dtype=np.float64)
    mujoco.mj_getState(model, data, state, STATE_SPEC)
    tmp = Path(path).with_suffix(".tmp")
    with tmp.open("wb") as stream:
        np.save(stream, state, allow_pickle=False)
    tmp.replace(path)


def load_state(model, data, path):
    state = np.load(path, allow_pickle=False)
    if state.shape != (mujoco.mj_stateSize(model, STATE_SPEC),) or not np.isfinite(state).all():
        raise RuntimeError("Invalid saved integration state")
    mujoco.mj_setState(model, data, state, STATE_SPEC)
    mujoco.mj_forward(model, data)


def request(repo, session, payload):
    session = Path(session).resolve()
    session.mkdir(parents=True, exist_ok=True)
    with (session / "session.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        action = payload.get("action")
        if action not in ("init", "apply", "reset", "show"):
            raise ValueError("Unknown request action")
        metadata_path = session / "model_metadata.json"
        state_path = session / "integration_state.npy"
        if action == "init":
            if metadata_path.exists() or state_path.exists():
                raise RuntimeError("Session already exists; use show or create a new session")
            model, data, metadata = official_model(repo)
            mujoco.mj_saveModel(model, str(session / "official_model.mjb"), None)
            metadata["model_binary_sha256"] = digest(session / "official_model.mjb")
            metadata["worker_sha256"] = digest(__file__)
            write_json(metadata_path, metadata)
        else:
            metadata = json.loads(metadata_path.read_text())
            if digest(session / "official_model.mjb") != metadata["model_binary_sha256"]:
                raise RuntimeError("Saved model hash mismatch")
            if digest(__file__) != metadata["worker_sha256"]:
                raise RuntimeError("Worker changed during session; start a new session")
            model = mujoco.MjModel.from_binary_path(str(session / "official_model.mjb"))
            data = mujoco.MjData(model)
            load_state(model, data, state_path)
        before_qpos = data.qpos.copy()
        before_ctrl = data.ctrl.copy()
        before_time = float(data.time)
        if action == "apply":
            step(model, data, payload["controls"])
        elif action == "reset":
            reset(model, data)
        changed = np.flatnonzero(np.abs(data.ctrl - before_ctrl) > 1e-12).tolist()
        event_id = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + "_" + uuid.uuid4().hex[:8]
        events = session / "events"
        events.mkdir(exist_ok=True)
        png = events / (event_id + ".png")
        # A renderer error stops this request before updated physics is committed.
        render(model, data, png)
        deltas = data.qpos - before_qpos
        observations = []
        for index in changed if action == "apply" else []:
            actuator = metadata["actuators"][index]
            qindex = actuator["qpos_index"]
            observations.append({
                "actuator_index": index, "actuator_name": actuator["name"],
                "joint": actuator["joint"], "unit": actuator["unit"],
                "ctrl_before": float(before_ctrl[index]), "ctrl_after": float(data.ctrl[index]),
                "qpos_before": float(before_qpos[qindex]), "qpos_after": float(data.qpos[qindex]),
                "qpos_delta": float(deltas[qindex]),
                "movement_observed": bool(abs(deltas[qindex]) > 1e-6),
            })
        event = {
            "event_id": event_id, "action": action,
            "utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "input_origin": payload.get("input_origin", "unspecified"),
            "not_original_vnc": True, "docker_used": False,
            "physics_steps": STEPS if action == "apply" else 0,
            "simulated_seconds_before": before_time,
            "simulated_seconds_after": float(data.time),
            "changed_control_indices": changed if action == "apply" else [],
            "ctrl_before": before_ctrl.tolist(), "ctrl_after": data.ctrl.tolist(),
            "qpos_before": before_qpos.tolist(), "qpos_after": data.qpos.tolist(),
            "qpos_delta": deltas.tolist(), "actuator_observations": observations,
            "png_path": str(png), "png_sha256": digest(png),
            "rendered_actual_scene": True,
            "causality_note": "Joint changes occur during coupled dynamics; deltas are observations, not an isolated causal estimate.",
        }
        save_state(model, data, state_path)
        write_json(events / (event_id + ".json"), event)
        with (session / "events.jsonl").open("a") as log:
            log.write(json.dumps(event, allow_nan=False) + "\n")
        seen = set()
        for line in (session / "events.jsonl").read_text().splitlines():
            old = json.loads(line)
            if old["input_origin"] == "notebook_apply_button" and old["action"] == "apply":
                seen.update(obs["actuator_index"] for obs in old["actuator_observations"] if obs["movement_observed"])
        coverage = {"observed_actuator_indices": sorted(seen), "count": len(seen), "total": 8,
                    "scope": "Alternative notebook Apply-button events with changed target and measured movement; does not certify original VNC or who operated the interface."}
        write_json(session / "coverage.json", coverage)
        result = {"ok": True, "metadata": metadata, "event": event,
                  "coverage": coverage, "session": str(session)}
        write_json(session / "latest.json", result)
        return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--session", required=True)
    args = parser.parse_args()
    try:
        result = request(args.repo, args.session, json.load(sys.stdin))
        print("PANDA_MANUAL_RESULT=" + json.dumps(result, allow_nan=False), flush=True)
    except Exception as error:
        import traceback
        traceback.print_exc()
        print("PANDA_MANUAL_RESULT=" + json.dumps({"ok": False, "error": str(error),
                                                 "error_type": type(error).__name__}), flush=True)
        sys.exit(1)
