"""Execute this file in the Kaggle Python 3.13 notebook kernel, after preparation.

Requires ROOT, REPO, PY and P1_MANUAL_IDLE_CONFIRMED=True in notebook globals.
MuJoCo/JAX are imported only by a subprocess using isolated Python 3.12.
"""
from pathlib import Path
import datetime as dt
import html
import importlib.metadata
import json
import os
import subprocess
import sys
import traceback
import uuid

assert globals().get("P1_MANUAL_IDLE_CONFIRMED") is True, (
    "Wait for all training/evaluation jobs to exit, then set P1_MANUAL_IDLE_CONFIRMED=True.")
try:
    import ipywidgets as widgets
    from IPython.display import display
except ImportError as error:
    raise RuntimeError("ipywidgets is unavailable in the notebook kernel. No installation was attempted.") from error

_manual_root = Path(ROOT)
_manual_repo = Path(REPO)
_manual_py = str(PY)
_manual_worker = _manual_root / "p1_manual_interface/panda_manual_worker.py"
assert _manual_worker.is_file(), str(_manual_worker)
assert Path(_manual_py).is_file(), _manual_py


def _manual_assert_idle():
    """Conservative process check; also requires the operator's explicit idle gate."""
    if globals().get("P1_MANUAL_IDLE_CONFIRMED") is not True:
        raise RuntimeError("Idle confirmation cleared; wait for training/evaluation to finish")
    busy = []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            argv = [part.decode(errors="replace") for part in (proc / "cmdline").read_bytes().split(b"\0") if part]
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        if not argv or not Path(argv[0]).name.startswith("python"):
            continue
        script_names = [Path(arg).name.lower() for arg in argv[1:] if arg.endswith(".py")]
        if any(name in ("train.py", "inference.py") or
               name.startswith(("evaluate_", "train_", "run_full")) or
               (name.startswith("p2_") and ("train" in name or "eval" in name))
               for name in script_names):
            busy.append({"pid": int(proc.name), "scripts": script_names})
    if busy:
        raise RuntimeError("Training/evaluation process detected; do not run manual renderer concurrently: " + json.dumps(busy))


def _manual_request(payload):
    _manual_assert_idle()
    env = os.environ.copy()
    env.update(JAX_PLATFORMS="cpu", XLA_PYTHON_CLIENT_PREALLOCATE="false",
               MUJOCO_GL="egl", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
               PYTHONUNBUFFERED="1", WANDB_MODE="disabled")
    env.pop("PYTHONPATH", None)
    result = subprocess.run([
        _manual_py, str(_manual_worker), "--repo", str(_manual_repo),
        "--session", str(_manual_session)], input=json.dumps(payload),
        text=True, capture_output=True, env=env, cwd=_manual_repo, timeout=120)
    _manual_session.mkdir(parents=True, exist_ok=True)
    with (_manual_session / "subprocess.log").open("a") as log:
        log.write("\nREQUEST " + json.dumps(payload) + "\n" + result.stdout + result.stderr)
    lines = [line.removeprefix("PANDA_MANUAL_RESULT=") for line in result.stdout.splitlines()
             if line.startswith("PANDA_MANUAL_RESULT=")]
    if result.returncode != 0 or not lines:
        raise RuntimeError("Manual worker failed; see subprocess.log.\n" + (result.stdout + result.stderr)[-4000:])
    report = json.loads(lines[-1])
    if not report["ok"]:
        raise RuntimeError(report["error"])
    return report


# Close a previous cell's controls so a rerun cannot leave two active UIs.
if "P1_MANUAL_WIDGET" in globals():
    for old_control in P1_MANUAL_WIDGET.get("controls", []):
        old_control.disabled = True
    P1_MANUAL_WIDGET["container"].close()

_manual_session = _manual_root / "run_evidence/p1_manual_interface" / (
    dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:8])
_manual_report = _manual_request({"action": "init", "input_origin": "notebook_initial_display"})
_manual_metadata = _manual_report["metadata"]
_manual_sliders = []
_manual_rows = []
for actuator in _manual_metadata["actuators"]:
    lo, hi = actuator["ctrlrange"]
    unit = actuator["unit"]
    label = (f"{actuator['index'] + 1}. {actuator['name']} → {actuator['joint']} "
             f"target ({unit}); limits [{lo:g}, {hi:g}]")
    if actuator["index"] == 7:
        label += "; both fingers coupled"
    slider = widgets.FloatSlider(value=actuator["home_ctrl"], min=lo, max=hi,
        step=0.01 if unit == "rad" else 0.001, description=f"#{actuator['index'] + 1}",
        continuous_update=False, readout=True, readout_format=".5f",
        layout=widgets.Layout(width="700px"), style={"description_width": "35px"})
    _manual_sliders.append(slider)
    _manual_rows.append(widgets.VBox([widgets.Label(label), slider]))

_manual_apply = widgets.Button(description="Apply", button_style="primary", icon="check")
_manual_reset = widgets.Button(description="Reset", button_style="warning", icon="undo")
_manual_status = widgets.HTML()
_manual_image = widgets.Image(format="png", width=640, height=480)
_manual_measurements = widgets.HTML()
_manual_errors = widgets.Output()


def _manual_show(report):
    event = report["event"]
    _manual_image.value = Path(event["png_path"]).read_bytes()
    coverage = report["coverage"]
    _manual_status.value = (
        f"<b>{html.escape(event['action'].upper())}</b>: {event['physics_steps']} actual MuJoCo steps; "
        f"simulation t={event['simulated_seconds_after']:.3f}s. "
        f"Changed controls with observed movement: <b>{coverage['count']}/8</b>.<br>"
        f"Event: {html.escape(event['event_id'])}")
    lines = ["Measured robot qpos (radians for arm; metres for fingers):"]
    for joint in report["metadata"]["robot_joints"]:
        index = joint["qpos_index"]
        lines.append(f"{joint['name']:14s} {event['qpos_after'][index]:+.7f}  delta {event['qpos_delta'][index]:+.7f}")
    for observation in event["actuator_observations"]:
        lines.append(f"Applied {observation['actuator_name']}: {observation['ctrl_before']:.5f} → "
                     f"{observation['ctrl_after']:.5f} {observation['unit']}; "
                     f"measured joint delta {observation['qpos_delta']:+.7f} {observation['unit']}")
    _manual_measurements.value = "<pre>" + html.escape("\n".join(lines)) + "</pre>"
    P1_MANUAL_WIDGET["latest"] = report


def _manual_click(action):
    _manual_errors.clear_output()
    controls = [_manual_apply, _manual_reset, *_manual_sliders]
    for control in controls:
        control.disabled = True
    _manual_status.value = "Running one bounded scene update…"
    try:
        payload = {"action": action, "input_origin": f"notebook_{action}_button"}
        if action == "apply":
            payload["controls"] = [slider.value for slider in _manual_sliders]
        report = _manual_request(payload)
        if action == "reset":
            for slider, value in zip(_manual_sliders, report["event"]["ctrl_after"]):
                slider.value = value
        _manual_show(report)
    except Exception:
        _manual_status.value = "Update failed. No successful update is claimed; inspect the error below."
        with _manual_errors:
            traceback.print_exc()
    finally:
        for control in controls:
            control.disabled = False


_manual_apply.on_click(lambda _: _manual_click("apply"))
_manual_reset.on_click(lambda _: _manual_click("reset"))
_manual_container = widgets.VBox([
    widgets.HTML("<h3>P1: eight-actuator manual control</h3>"
        "<b>Alternative notebook interface, not the original VNC or Docker GUI.</b><br>"
        "Change one slider, click Apply, inspect the actual PNG and measured qpos, then Reset before the next actuator. "
        "Apply advances native CPU MuJoCo physics by 200 steps (1 s). Sliders alone do not run physics. "
        "For actuator8, try 0.030 m from the 0.040 m home position.<br>"
        "Do not use this interface while training or evaluation is running."),
    *_manual_rows, widgets.HBox([_manual_apply, _manual_reset]),
    _manual_status, _manual_image, _manual_measurements, _manual_errors,
    widgets.Label("Evidence session: " + str(_manual_session)),
])
P1_MANUAL_WIDGET = {"container": _manual_container, "sliders": _manual_sliders,
    "apply": _manual_apply, "reset": _manual_reset, "session": str(_manual_session),
    "controls": [_manual_apply, _manual_reset, *_manual_sliders]}
_manual_show(_manual_report)
display(_manual_container)
print("Kernel", sys.version.split()[0], "ipywidgets", importlib.metadata.version("ipywidgets"))
print("If eight working sliders, Apply/Reset, and the actual PNG are not visibly rendered, widget support is NOT verified.")
print("SESSION", _manual_session)
